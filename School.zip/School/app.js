
  $("#register").validate({
    rules:{
       email:{
         required:true,
         email:true,
       },
   
       first_name:{
         required:true,
       },
   
     last_name:{
       required:true,
     },
   
     user_name:{
       required:true,
     },	
   
       user_name:{
       required:true,
     },
   
     user_password:{
       required:true,
       minlength: 8
       },
   
     confirm_password:{
       required: true,
       minlength: 8,
       equalTo:"#user_password"
       }
       
    //   subjects: {
    //    required: "#student_post:checked",
    //    minlength: 1
    //  }
     }
   });
   
   $('#login_form').validate({
     rules: {
   
       login_email: {
         required:true,
         email:true
       },
   
       login_password:{
         required: true
       }
     }
   });
   
   $('#reset_system').validate({
     rules: {
       reset_email: {
         required: true,
         email:true
       }
     }
   });
   
   $('#resetting_password').validate({
     new_password:{
       required:true,
       minlength: 8
       }
   });

$(document).ready(function(){
  $("input[name='option']").on('change',function(){
    var initial = $("input[name='option']:checked").val();
    console.log($("input[name='option']:checked").val());
    if(initial == 'Student'){
      $("#select-course").css('display','block');
    }else{
      $("#select-course").css('display','none');
    }
  });
});