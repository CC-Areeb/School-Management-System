<?php include('header.php'); ?>

<!-- 1st submit button to see their course -->
<body class="">
    <form action="student_details.php" id="student_login_form" method="POST" autocomplete="off">

        <label for="student_email">Enter your email:</label>
        <input type="text" name="student_email" id="student_email">
        <br><br>

        <label for="student_password">Enter your password:</label>
        <input type="password" name="student_password" id="student_password">
        <br><br>

        <label for="student_Id">Enter your Id:</label>
        <input type="text" name="student_Id" id="student_Id">
        <br><br>

        <input type="submit" name="submit" id="student_login" value="login">
    </form>
</body>
<!-- 1st submit button to see their course -->