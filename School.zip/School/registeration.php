<?php 
include('header.php');
?>
<body class="registeration_form_body">
	<form action="insert_query.php" id="register" method="post" autocomplete="off">
		<div class="registeration_form">

			<label for="first_name">First Name:</label><br>
			<input type="text" name="first_name" id="first_name"><br><br>

			<label for="last_name">Last Name:</label><br>
			<input type="text" name="last_name" id="last_name"><br><br>
	
			<label for="user_name">User Name:</label><br>
			<input type="text" name="user_name" id="user_name"><br><br>

			<label>Choose one of the following:</label><br><br>
			
			<label for="admin_post" class="container">
				<input type="radio" id="admin_post" name="option" value="Admin">
				<span class="checkmark"></span>
			Admin</label>

			<label for="teacher_post" class="container">
				<input type="radio" id="teacher_post" name="option" value="Teacher">
				<span class="checkmark"></span>
			Teacher</label>

			<label for="student_post" class="container">
			<input type="radio" id="student_post" name="option" value="Student">
			<span class="checkmark"></span>
			Student</label>
			<br><br>

			<fieldset id="select-course">
			<?php include('course_selection.php'); ?>
			</fieldset>
			
			<label for="email">Email:</label><br>
			<input type="email" name="email" id="email"><br><br>

			<label for="user_password">Password:</label><br>
			<input type="password" name="user_password" id="user_password"><br><br>

			<label for="confirm_password">Confirm password:</label><br>
			<input type="password" name="confirm_password" id="confirm_password"><br><br>			

			<input type="submit" name="submit" value="Register Now" class="register"><br><br>
		</div>
	</form>

	<span>Already have an account?</span>&nbsp;
	<a href="login.php" class="login">Login here</a>

	<script src="app.js"></script>
</body>
<?php
include('footer.php');
?>
