<!-- 
    
<form action="" method="post" name="courses" id="courses">
<label>Please choose your courses:</label>
<br><br>

<input type="checkbox" name="physics" id="physics">
<label for="physics">Physics</label>
<br><br>

<input type="checkbox" name="chemistry" id="chemistry">
<label for="chemistry">Chemistry</label>
<br><br>

<input type="checkbox" name="maths" id="maths">
<label for="maths">Maths</label>
<br><br>

<input type="checkbox" name="computer_science" id="computer_science">
<label for="computer_science">Computer Science</label>
<br><br> 
</form>

-->