<?php
include('database_connection.php');
if (isset($_POST['submit']))
{
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$user_name = $_POST['user_name'];
	$designation = $_POST['option'];
	$email = $_POST['email'];
	$user_password = md5($_POST['user_password']);
	$confirm_password = md5($_POST['confirm_password']);

	if ($_POST['option'] == 'Admin' || $_POST['option'] == 'Teacher')
	{
		if (md5($_POST['user_password']) == md5($_POST['confirm_password']))
		{
		$insert_query = "INSERT INTO User_Registeration (first_name, last_name, user_name, designation, email, password)
							 VALUES ('$first_name', '$last_name', '$user_name', '$designation', '$email', '$user_password')";

			if($_POST['option'] == 'Student')
			{
				
				if (mysqli_query($conn, $insert_query))
				{
					$insert_query = "INSERT INTO User_Registeration (first_name, last_name, user_name, designation, email, password)
									 VALUES ('$first_name', '$last_name', '$user_name', '$designation', '$email', '$user_password')";

					$last_id = mysqli_insert_id($conn, $insert_query);
					$cid = ($_POST['topic']);
					$ql = "";
					
					foreach($cid as $value)
					{
						$ql .= "INSERT INTO student_course_bridge (Id,course_id) VALUES('$last_id','$value');";
					
						if ($conn->multi_query($ql) === TRUE)
						{
							echo "<br> New record created successfully <br>";
						}
						
						else
						{
							echo "<br> Error: <br>" . $ql . "<br>" . $conn->error;
						}

					}	$conn->close();
				}
			}
				
			else
			{
				echo "<br> Error: <br>" . $ql . "<br>" . $conn->error;
			}
			$conn->close();
		}

		else
		{
			echo '<br> ERROR <br>';
		}

	}

	else
	{
		echo '<br> Something was wrong';
	}

}

if ($conn->query($insert_query) === TRUE)
{
  exit("<br><br> New record created successfully <br><br>");
} 
else
{
  exit("<br><br> Error: " . $insert_query . "<br><br>" . $conn->error);
}
?>

<!-- 

if (mysqli_query($conn, $insert_query)) {
				$last_id = mysqli_insert_id($conn, $insert_query);
				$cid = ($_POST['topic']);
				$ql = "";
				foreach($cid as $value){
					$ql .= "INSERT INTO student_course_bridge (Id,course_id) VALUES('$last_id','$value');";
				}
					if ($conn->multi_query($ql) === TRUE) {
					echo "<br> New record created successfully <br>";
					} else {
					echo "<br> Error: <br>" . $ql . "<br>" . $conn->error;
					}
					$conn->close();
			}
				else {
				echo "<br> Error: <br>" . $insert_query . "<br>" . $conn->error;
				}
				$conn->close();
 -->