<?php
include('database_connection.php');
$course_selection_query = "SELECT course_id, course_name FROM student_course ORDER BY course_id ASC";
$display_query = mysqli_query($conn, $course_selection_query);

    if (mysqli_num_rows($display_query) > 0){
        while($row = mysqli_fetch_assoc($display_query)){
            echo  '<label class="container2">
                        <input type="checkbox" name="topic[]" value="'.$row["course_id"].'">
                        <span class="checkmark2"></span>
                   </label>'. "(". $row["course_id"] .")". $row["course_name"];
        }
    }

    else{
        exit('No result');
    }

mysqli_close($conn);
?>