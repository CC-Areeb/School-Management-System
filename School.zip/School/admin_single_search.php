<?php
include('database_connection.php');

//Searching a single user with some input credentials 
if (isset($_POST['submit'])) {
    $search_user_first_name = $_POST['search_user_first_name'];
    $search_user_last_name = $_POST['search_user_last_name'];
    $select_user= $_POST['select_user'];

    $search_user_query = "SELECT * FROM User_Registeration WHERE first_name='$search_user_first_name' AND last_name='$search_user_last_name' AND designation='$select_user'";

    
    $search_result = mysqli_query($conn, $search_user_query);
    
    if (empty($_POST['search_user_first_name']) || empty($_POST['search_user_last_name']) || empty($_POST['select_user'])) 
    {
        echo "<br> Error, please provide the credentials <br>";
    }
    elseif (mysqli_num_rows($search_result) > 0){

        while($row = mysqli_fetch_assoc($search_result)){
            echo "<br> Id: " . ' ' . $row["Id"]. "<br> Name: " . $row["first_name"]. " " . $row["last_name"]. "<br> status: " . $row["designation"] ."<br>";
        }
    }
    else
    {
        echo '<br> No such user found <br>';
    }
}
//deleting a user by entering their Id//

elseif (isset($_POST['delete'])) {
    $delete_user = $_POST['delete_user'];

    $delete_user_query = " DELETE FROM User_Registeration WHERE Id = ' $delete_user' ";
    $delete_result = mysqli_query($conn, $delete_user_query);

    if (empty($_POST['delete_user'])) 
    {
        echo "<br> Error, please provide the Id <br>";
    }
    elseif (mysqli_num_rows($delete_result) > 0){

        while($row = mysqli_fetch_assoc($delete_result)){
            echo "User has been deleted";
        }
    }
    else
    {
        echo '<br> No such user found <br>';
    }
}
//Searching a single user with some input credentials


?>  

