<?php
include('database_connection.php');
include('header.php'); 

$sql = "SELECT Id, first_name, last_name FROM User_Registeration WHERE designation='Student'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    echo 'Id: ' . $row["Id"].  '<br> Name: ' . $row["first_name"].' ' .$row["last_name"]. '<br><br>' .
            '<form action="teacher_mark_attendance.php" method="POST">
            <label for="attendance">Attendance:</label><br>
            <input type="hidden" name="student_id[]" value="' . $row["Id"] . '" />
            <div class="custom-select">
                <select name="attendance[]">
                    <option>Attendance</option>
                    <option value="present">present</option>
                    <option value="absent">absent</option> 
                </select> 
            </div>'. 
    '<br><br> 
    <input type="submit" name="submit" value="Mark attendance" id="mark_attendance">
    <br><br>

    <label for="delete_attendance_fromId"> Enter student Id to delete their attendance</label>&nbsp;
    <input type="text" name="delete_attendance_fromId" id="delete_attendance_fromId" autocomplete="off">
    <br><br>

    <input type="submit" name="delete_attendance_ofStudent" class="delete_attendance_ofStudent" value="Delete Attendance">
    <br><br>
    <a href="teacher_homepage_form.php" class="back_to_main">Back to main page</a>

    </form>' . '<script src="custom_select_box.js"></script>';
   }
} 
else {
  echo "Error";
}

if (isset($_POST['submit'])) {
    $counter = 0;
    $status = $_POST['attendance[]'];
    foreach ($_POST['attendance'] as $key => $value) {
      $insert_query = " INSERT INTO student_attendance (student_id, status) VALUE ('".$_POST['student_id'] [$counter]. "', '$value')";
      
       //if ($_POST['attendance[]'] == 'present' || $_POST['attendance[]'] == 'absent') {  

        if (mysqli_query($conn, $insert_query)) {
            echo  "<br> New record created successfully <br>";
          } 
          else {
            echo "Error: " . $insert_query . "<br>" . mysqli_error($conn);
           }
          $counter++;
      //}

    //    else{
    //        echo'<br><br>Choose a valid option<br>';
    //    }
    }
    mysqli_close($conn);
}

elseif (isset($_POST['delete_attendance_ofStudent']))
{
    $delete_attendance_fromId = $_POST['delete_attendance_fromId'];
    $delete_query = " DELETE FROM student_attendance WHERE student_id = '$delete_attendance_fromId' ";
    $delete_Id_query_result = mysqli_query($conn, $delete_query);

    if (empty($_POST['delete_attendance_fromId'])) 
    {
        echo "<br> Error, please provide the Id <br>";
    }

    elseif (mysqli_num_rows($delete_Id_query_result) > 0) {
      while($row = mysqli_fetch_assoc($delete_Id_query_result)){
        echo "User has been deleted";
    }
  }
}
?>
<!--
<label for="delete_attendance_fromId"> Enter student Id to delete their attendance</label>&nbsp;
<input type="text" name="delete_attendance_fromId" id="delete_attendance_fromId">

<input type="submit" name="delete_attendance_ofStudent" value="Delete Attendance">

<a href="teacher_homepage_form.php">Back to main page</a>
-->




