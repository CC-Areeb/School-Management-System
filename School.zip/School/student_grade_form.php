<form action="student_grade_process.php" method="POST" autocomplete="off">
  <input type="hidden" name="student" value=" ' . $row['Id'] . ' ">

  <label>Physics:</label>
  <input type="text" name="physics_grade" id="physics_grade">

  <label>Chemistry:</label>
  <input type="text" name="chemistry_grade" id="chemistry_grade">

  <label>Maths:</label>
  <input type="text" name="maths_grade" id="maths_grade">

  <label>Biology:</label>
  <input type="text" name="biology_grade" id="biology_grade">
<br>

