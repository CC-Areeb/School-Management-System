<?php
include('header.php');
include('database_connection.php'); 
$display_students = "SELECT Id, first_name, last_name FROM User_Registeration WHERE designation='Student'";
$result = mysqli_query($conn, $display_students);

if (mysqli_num_rows($result) > 0) { 
  while($row = mysqli_fetch_assoc($result)) {
    echo "<br><br> Id: " . $row["Id"]. " - Name: " . $row["first_name"].' '.$row["last_name"].'<br>';    
    include('student_grade_form.php');

    if(isset($_POST['submit'])){
      $physics_grade = $_POST['physics_grade'];
      $chemistry_grade = $_POST['chemistry_grade'];
      $maths_grade = $_POST['maths_grade'];
      $biology_grade = $_POST['biology_grade'];
  
      $insert_grade = "INSERT INTO student_grade (student_id ,physics, chemistry, biology, maths) 
                       VALUES (".$row["Id"].", '$physics_grade', '$chemistry_grade', '$biology_grade', '$maths_grade')";
     
     if (empty($_POST['physics_grade']) || empty($_POST['chemistry_grade']) || empty($_POST['maths_grade']) || empty($_POST['biology_grade'])) {
      echo '<br><br> Please grade the students <br>';
   }
   elseif (mysqli_query($conn, $insert_grade)) {
       echo "<br><br> New record created successfully <br>";
   }
   else{
       echo "<br><br> Error: " . $insert_grade . "<br><br>" . mysqli_error($conn);
   }

  }
}
echo
'<br><br>'.'<input type="submit" name="submit" id="submit_grade" value="Submit Grades">';
'</form>';
}
?>

<!-- 
if (empty($_POST['physics_grade']) || empty($_POST['chemistry_grade']) || empty($_POST['maths_grade']) || empty($_POST['biology_grade'])) {
         echo '<br><br> Please grade the students <br>';
      }
      elseif (mysqli_query($conn, $insert_grade)) {
          echo "<br><br> New record created successfully <br>";
      }
      else{
          echo "<br><br> Error: " . $insert_grade . "<br><br>" . mysqli_error($conn);
      }
 -->