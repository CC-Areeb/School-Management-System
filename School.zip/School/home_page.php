<?php
include('header.php');
// echo "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]). "/update_password.php?code=$code";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body class="home_page_body">
    <h1>Welcome To ABC University</h1>

<div class="card_1">

<div class="flip-card_1">
  <div class="flip-card-inner_1">
    <div class="flip-card-front_1">
      <img src="images/person_1.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Theoretical physicist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

<div class="flip-card_2">
  <div class="flip-card-inner_2">
    <div class="flip-card-front_2">
      <img src="images/person_2.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_2">
      <h1>John Doe</h1> 
      <h4><p>Theoretical physicist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

  <img src="images/physics.png" alt="Theoratical Physics" style="width:100%">
  <div class="container">
    <h2><b>Department of Physics</b></h2> 
    <h3>Theoretical Physics</h3> 
    <p>
        Theoretical physics is a branch of physics that employs
        mathematical models and abstractions of physical objects
        and systems to rationalize, explain and predict natural phenomena.
        This is in contrast to experimental physics, which uses experimental
        tools to probe these phenomena.
    </p>
  </div>
</div>

<div class="card_2">

<div class="flip-card_3">
  <div class="flip-card-inner_3">
    <div class="flip-card-front_3">
      <img src="images/person_3.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

<div class="flip-card_4">
  <div class="flip-card-inner_4">
    <div class="flip-card-front_4">
      <img src="images/person_4.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

  <img src="images/chemistry.jpg" alt="Biomedical Chemistry" style="width:100%">
  <div class="container">
    <h2><b>Department of Chemistry</b></h2> 
    <h3>Biomedical Chemistry</h3>
    <p>
        Biomedical chemists are medical scientists.
        They perform scientific research and apply
        chemical principles to study human diseases,
        their origins, and how to best treat them.
        They also create and study new pharmaceutical
        drugs to treat them.
    </p> 
  </div>
</div>

<div class="card_3">

<div class="flip-card_5">
  <div class="flip-card-inner_5">
    <div class="flip-card-front_5">
      <img src="images/person_3.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

<div class="flip-card_6">
  <div class="flip-card-inner_6">
    <div class="flip-card-front_6">
      <img src="images/person_4.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

  <img src="images/biology.jpg" alt="Neurobiology and Behavior" style="width:100%">
  <div class="container">
    <h2><b>Department of Neuroscience</b></h2> 
    <h3>Neurobiology and Behavior</h3> 
    <p>
        Neuroscience is the scientific study of the nervous system.
        It is a multidisciplinary science that combines physiology,
        anatomy, molecular biology, developmental biology, cytology,
        computer science and mathematical modeling to understand the
        fundamental and emergent properties of neurons, glia and neural
        circuits.
    </p>
  </div>
</div>

<div class="card_4">

<div class="flip-card_7">
  <div class="flip-card-inner_7">
    <div class="flip-card-front_7">
      <img src="images/person_1.png" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>

<div class="flip-card_8">
  <div class="flip-card-inner_8">
    <div class="flip-card-front_8">
      <img src="images/person_2.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    <div class="flip-card-back_1">
      <h1>Lorem Ipsum</h1> 
      <h4><p>Biomedical Chemist</p></h4> 
      <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit.
          Tenetur atque iusto ratione sed placeat, animi nisi at? Est
          labore excepturi odio voluptatibus iste, assumenda impedit qui
          dolores minima, beatae at tenetur incidunt. Doloribus eos
          numquam itaque, reprehenderit incidunt mollitia beatae!
      </p>
    </div>
  </div>
</div>  

  <img src="images/math.jpeg" alt="Mathematician" style="width:100%">
  <div class="container">
    <h2><b>Department of Mathematics</b></h2> 
    <h3>Mathematician</h3> 
    <p>
        A mathematician is someone who uses an extensive knowledge
        of mathematics in their work, typically to solve mathematical
        problems. Mathematicians are concerned with numbers, data, quantity,
        structure, space, models, and change.
    </p>
  </div>
</div>


    <span>Register here</span>&nbsp;
    <a href="registeration.php" class="register">Register</a>
	<br><br><br>

    <span>Already have an account?</span>&nbsp;
	<a href="login.php" class="login">Login here</a>
    <br>
</body>
</html>



<?php include('footer.php'); ?>