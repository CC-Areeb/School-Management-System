<?php
include('database_connection.php');

if (isset($_POST['submit'])) {
    $see_all_users = $_POST['see_all_users'];

    //all queries//
    
    $select_all_admin = " SELECT Id, first_name, last_name, designation FROM User_Registeration WHERE designation='Admin'";
    $all_admins_result = mysqli_query($conn, $select_all_admin);

    $select_all_teacher = " SELECT Id, first_name, last_name, designation FROM User_Registeration WHERE designation='Teacher'";
    $all_teachers_result = mysqli_query($conn, $select_all_teacher);

    $select_all_students = " SELECT Id, first_name, last_name, designation FROM User_Registeration WHERE designation='Student'";
    $all_students_result = mysqli_query($conn, $select_all_students);
            
    // $select_all_users = " SELECT Id, first_name, last_name, designation FROM User_registeration";
    // $all_users_result = mysqli_query($conn, $select_all_users);

    //all queries//

    if ($_POST['see_all_users'] == 'admins')
    {
        if (mysqli_num_rows($all_admins_result) > 0)
        {
            while($row = mysqli_fetch_assoc($all_admins_result))
            {
                echo "Id: " . $row["Id"]. " <br> Name: " . $row["first_name"]. " " . $row["last_name"]. " <br> Status : " . $row["designation"] ."<br><br>";
            }
        }
    }

    elseif ($_POST['see_all_users'] == 'teachers')
    {
        if (mysqli_num_rows($all_teachers_result) > 0)
        {
            while($row = mysqli_fetch_assoc($all_teachers_result))
            {
                echo "Id: " . $row["Id"]. " <br> Name: " . $row["first_name"]. " " . $row["last_name"]. " <br> Status : " . $row["designation"] ."<br><br>";
            }
        }
    }

    elseif ($_POST['see_all_users'] == 'students')
    {
        if (mysqli_num_rows($all_students_result) > 0)
        {
            while($row = mysqli_fetch_assoc($all_students_result))
            {
                echo "Id: " . $row["Id"]. " <br> Name: " . $row["first_name"]. " " . $row["last_name"]. " <br> Status : " . $row["designation"] ."<br><br>";
            }
        }
    }

    // elseif ($_POST['see_all_users'] == 'everyone')
    // {
    //     if (mysqli_num_rows($all_users_result) > 0)
    //     {
    //         var_dump('$all_users_result');
    //         while($row = mysqli_fetch_assoc($all_users_result))
    //         {
    //             echo "Id: " . $row["Id"]. " <br> Name: " . $row["first_name"]. " " . $row["last_name"]. " <br> Status : " . $row["designation"] ."<br><br>";
    //         }
    //     }
    // }

    else
    {
        echo'Cannot display the result as you have not selected any option';
    }
}
?>