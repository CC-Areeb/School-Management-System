<?php

// if (session_destroy()) {
//     header("location: login.php");
// }
// exit();


// if(empty($_SESSION['email']))
// {
// 	header("location: login.php");
// }

// if(isset($_POST['logout'])) {
//     session_destroy();
//     unset($_SESSION['login_email']);
//     header('location: login.php');
// }

// session_start(); 
// if (session_destroy()) {
//     header("location: login.php");
// }

// if (unset($_SESSION[''])) {
//     # code...
// }
?>