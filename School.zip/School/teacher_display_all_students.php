<?php
session_start();
include('database_connection.php');
if(isset($_POST['teacher_see_all']))
{
    $login_email = $_SESSION['login_email'];
    $see_all_students = " SELECT Id, first_name, last_name, designation FROM User_Registeration WHERE designation='Student'";
    $see_all_query = mysqli_query($conn, $see_all_students);

    if (mysqli_num_rows($see_all_query) > 0)
        {
            while($row = mysqli_fetch_assoc($see_all_query))
            {
                echo "Id: " . $row["Id"]. " <br> Name: " . $row["first_name"]. " " . $row["last_name"]. " <br> Status : " . $row["designation"] ."<br><br>";
            }
        }
}

include('logout.php');
?>

<?php

?>

<!-- 
if session exits then destroy session and redirect the user to login.php

else if session does not exist then still keep user on the login page aka login.php
-->

