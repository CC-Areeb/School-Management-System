<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style.css">

	<script src="http://code.jquery.com/jquery-3.5.1.min.js"></script>
	
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" integrity="sha512-37T7leoNS06R80c8Ulq7cdCDU5MNQBwlYoy1TX/WUsLFC2eYNqtKlV0QjH7r8JpG/S0GUMZwebnVFLPd6SU5yg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script type="text/javascript" src="js/jquery.validate.js"></script>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ABC University</title>
</head>
<body>
	<div class="heading_section">
		<h1>ABC University</h1>
	</div>