<?php
$servername = "localhost";
$username = "root";
$password = "Areeb123_";
$dbname = "school-management-system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: <br><br>" . $conn->connect_error);
}
// echo "Connected successfully <br><br>";
?>