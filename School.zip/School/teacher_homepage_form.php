<?php
include('header.php');
?>

<body class="teacher_home_body">
  <form action="teacher_mark_attendance.php" method="POST">
    <div class="button"> 
        <button type="submit" id="attendance_submit_btn" name="submit">Attendance Page</button>
    </div>
  </form>



  <form action="teacher_display_all_students.php" id="teacher_attendance_display" method="POST">
      <br>
      <a href="student_grade_process.php" id="student_grade_process">Grade students</a>
    <br><br>

    <input type="submit" name="teacher_see_all" id="teacher_see_all" value="See all students">
  </form>
  <br><br>
  <a href="<?php include('logout.php'); ?>" class="logout_btn">log out</a>
</body>