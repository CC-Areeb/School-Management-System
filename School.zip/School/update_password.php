<?php
include('header.php');
include('database_connection.php');

if (!isset($_GET["code"])) {
    exit("Code expired");
}

$code = $_GET["code"];

// $get_email_query = " SELECT reset_email FROM reset_password WHERE code='$code' ";
$get_mail = mysqli_query($conn, " SELECT reset_email FROM reset_password WHERE code='$code' "); // pass this variable to fire the query

if (mysqli_num_rows($get_mail) == 0) {
    exit("Page not available");
}

if (isset($_POST["new_password"])) {
    $new_password = $_POST["new_password"];
    $new_password = md5($new_password);
    $row = mysqli_fetch_array($get_mail);
    $email = $row["reset_email"];

    $update_query = " UPDATE User_Registeration SET password ='$new_password' WHERE  email = '$email'";
    $updating = mysqli_query($conn, $update_query);

    if ($updating) {
        $delete_query = " DELETE FROM reset_password WHERE code = '$code' ";
        $deleting = mysqli_query($conn, $delete_query);
        exit("password update");
    }

    else{
        exit("Something went wrong");
    }
}
?>

<form method="POST" autocomplete="off" name="resetting_password">
        <label for="new_password">Type a new password</label>
        <br>
        <input type="password" name="new_password" id="new_password">
        <br>
        <input type="submit" name="submit" value="Update password">
    </form>



    <script src="app.js"></script>

<?php

include('footer.php');
?>