<body class="login_body">
	<form action="" method="post" id="login_form" autocomplete="off">	
		<label for="login_email">Email:</label><br>
		<input type="text" name="login_email" id="login_email"><br><br>

		<label for="login_password">Password:</label><br>
		<input type="password" name="login_password" id="login_password"><br><br>

		<label>Choose one of the following:</label><br><br>
	
		<label for="admin_post" class="container">
				<input type="radio" id="admin_post" name="option" value="Admin">
				<span class="checkmark"></span>
			Admin</label>

			<label for="teacher_post" class="container">
				<input type="radio" id="teacher_post" name="option" value="Teacher">
				<span class="checkmark"></span>
			Teacher</label>

			<label for="student_post" class="container">
			<input type="radio" id="student_post" name="option" value="Student">
			<span class="checkmark"></span>
			Student</label>
		
		<input type="submit" name="submit" class="login" value="Login">
	</form>
	<br>

	<span>Register here if you don't have an account</span>
	&nbsp;
	<a href="registeration.php" class="register">Register</a>
	<br><br>

	<span>Forgot password?</span> 
	<a href="reset_password.php" class="reset">Reset password</a>
	<br><br>

	<script type="text/javascript" src="app.js"></script>
</body>

<?php 
session_start();
include('database_connection.php');
include('header.php');
if (isset($_POST['submit'])) {	

	$login_email = $_POST['login_email'];
	$login_password = md5($_POST['login_password']);
	$option = $_POST['option'];

	$selection_query ="select * from User_Registeration where email = '$login_email' and password = '$login_password' and designation = '$option' ";
	$selection = mysqli_query($conn, $selection_query);
	$row = mysqli_fetch_array($selection);
	if (isset($row)){

		$_SESSION['email'] = $row['login_email'];
		// $_SESSION['password'] = $row['login_password'];

		if($_POST['option'] == 'Teacher'){
			header("location: teacher_homepage_form.php");
		}

		elseif($_POST['option'] == 'Admin'){
			header("location: admin_home_page.php");
		}

		elseif($_POST['option'] == 'Student'){
			header("location: student_home_page.php");
		}
		else{
			echo'No entry';
			// exit('Please choose a designation');
		}
	}
	

	else{
		echo '<script type="text/javascript">';
		echo 'alert("Invalid user email or password")';
		echo 'window.location.href = "login.php"';
		echo '</script>';
	}

		
	}

// echo "<a href="<?php include('logout.php'); ?>"></a>";

include('footer.php');
// include('logout.php');
?>