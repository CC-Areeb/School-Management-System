<?php
include('header.php');
?>
<body class="admin_body">
    <form action="admin_single_search.php" id="single_search_user" method="POST" autocomplete="off">    
        <label>Search user</label>
        <br><br>

        <label for="search_user_first_name">First name:</label>
        <input type="text" name="search_user_first_name" id="search_user_first_name">
        &nbsp;
        <label for="search_user_last_name">Last name:</label>
        <input type="text" name="search_user_last_name" id="search_user_last_name">
        <br><br>

        <input type="radio" name="select_user" id="select_admin" value="admin">
        <label for="select_admin">Admin</label>
        

        <input type="radio" name="select_user" id="select_teacher" value="teacher">
        <label for="select_teacher">Teacher</label>
    

        <input type="radio" name="select_user" id="select_student" value="student">
        <label for="select_student">Student</label>
        <br>

        <br><br>
        <input type="submit" id="single_search_user_btn" name="submit" value="Search User">
        <br><br><br><br> 

        <label>Provide the user id to proceed with account deletion</label>
        <br><br>

        <label for="delete_with_id">Enter Id to delete user</label>
        <input type="text" name="delete_user" id="delete_with_id">
        <br><br>
        <input type="submit" name="delete" value="Delete User">
        
    </form>
</body>

<?php
include('admin_single_search.php');
?>

<body class="admin_body">
    <form action="admin_all_user_search.php" id="view_all" method="POST">
        <h4>View all users one by one</h4>

        <input type="radio" name="see_all_users" id="see_all_admins" value="admins">
        <label for="see_all_admins">All Administrators</label>

        <input type="radio" name="see_all_users" id="see_all_teacher" value="teachers">
        <label for="see_all_teacher">All Teachers</label>

        <input type="radio" name="see_all_users" id="see_all_student" value="students">
        <label for="see_all_student">All Students</label>

        <!-- <input type="radio" name="see_all_users" id="see_all" value="everyone">
        <label for="see_all">Everyone</label> -->
        
        <br><br> 

        <input type="submit" name="submit" id="search_all" value="Search">
    </form>

    <br><br> 
    <a href="logout.php" class="logout_btn">log out</a>
</body>

<?php
include('admin_all_user_search.php');
?>



