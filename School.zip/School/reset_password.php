<?php
include('header.php');
include('database_connection.php');

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
//Load Composer's autoloader
require 'vendor/autoload.php';
//get data from form

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

if (isset($_POST['reset_email'])) {

    $send_email_to = $_POST['reset_email'];            
    $code = uniqid(true);  //getting code for resetting here

    //
    $resetting_query = "INSERT INTO reset_password (code, reset_email) VALUES ('$code' , '$send_email_to') ";
    $reset_password = mysqli_query($conn, $resetting_query);
    
    if (!$reset_password) {
        exit('There was an error');
    }

    try {
        //Server settings
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                 //Enable verbose debug output
        $mail->isSMTP();                                         //Send using SMTP
        $mail->Host       = 'smtp.mailtrap.io';                  //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                //Enable SMTP authentication
        $mail->Username   = 'ff0e8e7d71dd6e';                    //SMTP username
        $mail->Password   = 'e54feb0c657289';                    //SMTP password
        $mail->Port       = 2525;                                //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        //Recipients
        $mail->setFrom('from@example.com', 'The staff');
        $mail->addAddress($send_email_to, 'Someone');            //Add a recipient
        // $mail->addAddress('ellen@example.com');               //Name is optional
        $mail->addReplyTo('info@example.com', 'Information');


        //making a link for resetting code
        $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]). "/update_password.php?code=$code";
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Resetting Password';
        $mail->Body    =  "Reset code:- <a href='$url'>your code</a>";
        $mail->send();
        echo 'Reset link has been sent to your email';
    } catch (Exception $e) {
       echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    exit();
}

        
?>
<body class="reset_password_body">
    <form method="POST" name="reset_system" id="reset_password_system" autocomplete="off">
        <label for="reset_email">Input an email where we can send you the reset password link \(^-^)/ </label>
        <br><br>
        <input type="email" name="reset_email" id="reset_email">
        <br><br>
        <input type="submit" name="submit" id="reset_password_btn" value="Send mail"><br>
        <br>
    </form>

    <label>Don't have an account? register here</label>
    <a href="registeration.php" class="register">Register</a>
    <br><br>

    <label>Already have an account? login here</label>
    <a href="login.php" class="login_btn">Log in</a>

    <script src="app.js"></script>
</body>